/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.spi;

public class ProviderNotFoundException extends Exception
{
  public ProviderNotFoundException( String message )
  {
    super( message );
  }
  
  public ProviderNotFoundException( String message, Throwable cause )
  {
    super( message, cause );
  }
}
