/*
 * @(#)IdentifierExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression representing an unqualified name. <p/>
 *
 * @author Andy Yu
 * */
public interface IdentifierExpressionT
  extends ExpressionT, HasNameT
{
}
