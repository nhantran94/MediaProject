/*
 * @(#)ThrowsT.java
 */

package javax.ide.model.java.source.tree;

import java.util.List;

/**
 * A throws clause of a method or constructor declaration.
 *
 * @author Andy Yu
 * */
public interface ThrowsT
  extends Tree
{
  // ----------------------------------------------------------------------

  /**
   * Gets the list of thrown exceptions.
   *
   * @return The list of thrown exceptions. <p/>
   *
   * List of TypeReferenceTs.
   */
  public List getExceptions();


  // ----------------------------------------------------------------------
}
