/*
 * @(#)FinallyClauseT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A finally clause. JLS3 14.20. <p/>
 *
 * @author Andy Yu
 * */
public interface FinallyClauseT
  extends CompoundStatementT
{
  // ----------------------------------------------------------------------

  /**
   * @return The owning try statement. Null if none (i.e. deformed tree).
   */
  public TryStatementT getOwningTry();
}
