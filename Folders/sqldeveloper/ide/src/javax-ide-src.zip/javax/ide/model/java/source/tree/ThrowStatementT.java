/*
 * @(#)ThrowStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A throw statement. JLS3 14.18.
 *
 * @author Andy Yu
 * */
public interface ThrowStatementT
  extends SimpleStatementT
{
}
